PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE residents (
            unique_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            age INTEGER,
            gender TEXT,
            address TEXT,
            phone TEXT,
            village_area TEXT,
            photo_path TEXT,
            registration_date TEXT,
            registered_by TEXT
        );
CREATE TABLE visits (
            visit_id INTEGER PRIMARY KEY AUTOINCREMENT,
            resident_id TEXT,
            visit_date TEXT,
            visit_time TEXT,
            health_worker TEXT,
            bp_systolic INTEGER,
            bp_diastolic INTEGER,
            temperature REAL,
            pulse INTEGER,
            weight REAL,
            height REAL,
            bmi REAL,
            spo2 INTEGER,
            complaints TEXT,
            observations TEXT,
            photo_paths TEXT,
            FOREIGN KEY (resident_id) REFERENCES residents(unique_id)
        );
CREATE TABLE medical_history (
            history_id INTEGER PRIMARY KEY AUTOINCREMENT,
            resident_id TEXT,
            chronic_conditions TEXT,
            past_diagnoses TEXT,
            current_medications TEXT,
            allergies TEXT,
            family_history TEXT,
            notes TEXT,
            last_updated TEXT,
            updated_by TEXT,
            FOREIGN KEY (resident_id) REFERENCES residents(unique_id)
        );
DELETE FROM sqlite_sequence;
CREATE INDEX idx_resident_id ON visits(resident_id)
    ;
CREATE INDEX idx_visit_date ON visits(visit_date)
    ;
CREATE INDEX idx_medical_history_resident ON medical_history(resident_id)
    ;
COMMIT;
